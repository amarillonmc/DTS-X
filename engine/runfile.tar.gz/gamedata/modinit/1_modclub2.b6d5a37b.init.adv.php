<?php

namespace club2
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/clubs/club2/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_CLUB2_PRESET_VARS','');
define('___LOAD_MOD_CLUB2_PRESET_VARS','');
define('MODULE_CLUB2_GLOBALS_VARNAMES','');
define('MOD_CLUB2',1);
define('IMPORT_MODULE_CLUB2_GLOBALS','');
define('PREFIX_MODULE_CLUB2_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_CLUB2_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_CLUB2__VARS_____PRIVATE_PFUNC,$___PRIVATE_CLUB2__VARS_____PRIVATE_CFUNC;
$___PRIVATE_CLUB2__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_CLUB2__VARS_____PRIVATE_CFUNC=Array();


function ___post_init() { global $___PRIVATE_CLUB2__VARS_____PRIVATE_PFUNC,$___PRIVATE_CLUB2__VARS_____PRIVATE_CFUNC;


}
	
}

?>