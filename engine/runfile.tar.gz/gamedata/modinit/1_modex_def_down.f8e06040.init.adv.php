<?php

namespace ex_def_down
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/ex_def_down/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EX_DEF_DOWN_PRESET_VARS','');
define('___LOAD_MOD_EX_DEF_DOWN_PRESET_VARS','');
define('MODULE_EX_DEF_DOWN_GLOBALS_VARNAMES','');
define('MOD_EX_DEF_DOWN',1);
define('IMPORT_MODULE_EX_DEF_DOWN_GLOBALS','');
define('PREFIX_MODULE_EX_DEF_DOWN_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_EX_DEF_DOWN_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EX_DEF_DOWN__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_DEF_DOWN__VARS_____PRIVATE_CFUNC;
$___PRIVATE_EX_DEF_DOWN__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EX_DEF_DOWN__VARS_____PRIVATE_CFUNC=Array();

hook_register('ex_def_down','get_def_multiplier');
function ___post_init() { global $___PRIVATE_EX_DEF_DOWN__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_DEF_DOWN__VARS_____PRIVATE_CFUNC;


}
	
}

?>