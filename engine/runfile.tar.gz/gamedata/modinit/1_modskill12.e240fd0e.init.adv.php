<?php

namespace skill12
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill12/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL12_PRESET_VARS','');
define('___LOAD_MOD_SKILL12_PRESET_VARS','');
define('MOD_SKILL12_INFO','club;active;locked;');
define('MOD_SKILL12_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill12/desc');
define('MOD_SKILL12_PROFILECMD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill12/profilecmd');
define('MODULE_SKILL12_GLOBALS_VARNAMES','');
define('MOD_SKILL12',1);
define('IMPORT_MODULE_SKILL12_GLOBALS','');
define('PREFIX_MODULE_SKILL12_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL12_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL12__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL12__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL12__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL12__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill12','acquire12');hook_register('skill12','lost12');hook_register('skill12','check_unlocked12');hook_register('skill12','act');hook_register('skill12','cast_skill12');
function ___post_init() { global $___PRIVATE_SKILL12__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL12__VARS_____PRIVATE_CFUNC;


}
	
}

?>