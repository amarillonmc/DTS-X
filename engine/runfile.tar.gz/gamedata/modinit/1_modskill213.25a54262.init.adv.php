<?php

namespace skill213
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill213/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL213_PRESET_VARS','');
define('___LOAD_MOD_SKILL213_PRESET_VARS','');
define('MOD_SKILL213_INFO','club;');
define('MOD_SKILL213_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill213/desc');
define('MODULE_SKILL213_GLOBALS_VARNAMES','');
define('MOD_SKILL213',1);
define('IMPORT_MODULE_SKILL213_GLOBALS','');
define('PREFIX_MODULE_SKILL213_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL213_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL213__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL213__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL213__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL213__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill213','acquire213');hook_register('skill213','lost213');hook_register('skill213','check_unlocked213');hook_register('skill213','apply_attack_exp_gain');
function ___post_init() { global $___PRIVATE_SKILL213__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL213__VARS_____PRIVATE_CFUNC;


}
	
}

?>