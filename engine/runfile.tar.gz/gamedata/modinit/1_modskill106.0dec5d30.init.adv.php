<?php

namespace skill106
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill106/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL106_PRESET_VARS','');
define('___LOAD_MOD_SKILL106_PRESET_VARS','');
define('MOD_SKILL106_INFO','club;locked;');
define('MOD_SKILL106_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill106/desc');
define('MODULE_SKILL106_GLOBALS_VARNAMES','');
define('MOD_SKILL106',1);
define('IMPORT_MODULE_SKILL106_GLOBALS','');
define('PREFIX_MODULE_SKILL106_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL106_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL106__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL106__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL106__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL106__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill106','acquire106');hook_register('skill106','lost106');hook_register('skill106','check_unlocked106');
function ___post_init() { global $___PRIVATE_SKILL106__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL106__VARS_____PRIVATE_CFUNC;


}
	
}

?>