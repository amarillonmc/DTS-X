<?php

namespace skill219
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill219/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL219_PRESET_VARS','');
define('___LOAD_MOD_SKILL219_PRESET_VARS','');
define('MOD_SKILL219_INFO','club;active;feature;');
define('MOD_SKILL219_PROFILECMD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill219/profilecmd');
define('MOD_SKILL219_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill219/desc');
define('MODULE_SKILL219_GLOBALS_VARNAMES','');
define('MOD_SKILL219',1);
define('IMPORT_MODULE_SKILL219_GLOBALS','');
define('PREFIX_MODULE_SKILL219_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL219_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL219__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL219__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL219__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL219__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill219','acquire219');hook_register('skill219','lost219');hook_register('skill219','check_unlocked219');hook_register('skill219','wpoison');hook_register('skill219','act');
function ___post_init() { global $___PRIVATE_SKILL219__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL219__VARS_____PRIVATE_CFUNC;


}
	
}

?>