<?php

namespace skill100
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill100/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL100_PRESET_VARS','');
define('___LOAD_MOD_SKILL100_PRESET_VARS','');
define('MOD_SKILL100_INFO','club;upgrade;');
define('MOD_SKILL100_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill100/desc');
define('MODULE_SKILL100_GLOBALS_VARNAMES','');
define('MOD_SKILL100',1);
define('IMPORT_MODULE_SKILL100_GLOBALS','');
define('PREFIX_MODULE_SKILL100_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL100_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL100__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL100__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL100__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL100__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill100','acquire100');hook_register('skill100','lost100');hook_register('skill100','check_unlocked100');hook_register('skill100','upgrade100');hook_register('skill100','itemmix_success');hook_register('skill100','recipe_mix_success');hook_register('skill100','skill100_check');
function ___post_init() { global $___PRIVATE_SKILL100__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL100__VARS_____PRIVATE_CFUNC;


}
	
}

?>