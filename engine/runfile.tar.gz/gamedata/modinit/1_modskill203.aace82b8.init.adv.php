<?php

namespace skill203
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill203/'.$___TEMP_key; 
	
	$___PRESET_SKILL203__VARS__ragecost=$ragecost;$___PRESET_SKILL203__VARS__wep_skillkind_req=$wep_skillkind_req;
function ___pre_init() { global $___PRESET_SKILL203__VARS__ragecost,$ragecost,$___PRESET_SKILL203__VARS__wep_skillkind_req,$wep_skillkind_req;$ragecost=$___PRESET_SKILL203__VARS__ragecost;$wep_skillkind_req=$___PRESET_SKILL203__VARS__wep_skillkind_req; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL203_PRESET_VARS','$___PRESET_SKILL203__VARS__ragecost=$ragecost;$___PRESET_SKILL203__VARS__wep_skillkind_req=$wep_skillkind_req;');
define('___LOAD_MOD_SKILL203_PRESET_VARS','global $___PRESET_SKILL203__VARS__ragecost,$ragecost,$___PRESET_SKILL203__VARS__wep_skillkind_req,$wep_skillkind_req;$ragecost=$___PRESET_SKILL203__VARS__ragecost;$wep_skillkind_req=$___PRESET_SKILL203__VARS__wep_skillkind_req;');
define('MOD_SKILL203_INFO','club;battle;');
define('MOD_SKILL203_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill203/desc');
define('MOD_SKILL203_BATTLECMD_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill203/battlecmd_desc');
define('MODULE_SKILL203_GLOBALS_VARNAMES','ragecost,wep_skillkind_req');
define('MOD_SKILL203',1);
define('IMPORT_MODULE_SKILL203_GLOBALS','global $___LOCAL_SKILL203__VARS__ragecost,$___LOCAL_SKILL203__VARS__wep_skillkind_req; $ragecost=&$___LOCAL_SKILL203__VARS__ragecost; $wep_skillkind_req=&$___LOCAL_SKILL203__VARS__wep_skillkind_req; ');
define('PREFIX_MODULE_SKILL203_GLOBALS','\'; global $___LOCAL_SKILL203__VARS__ragecost; ${$___TEMP_PREFIX.\'ragecost\'}=&$___LOCAL_SKILL203__VARS__ragecost; global $___LOCAL_SKILL203__VARS__wep_skillkind_req; ${$___TEMP_PREFIX.\'wep_skillkind_req\'}=&$___LOCAL_SKILL203__VARS__wep_skillkind_req; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL203_GLOBALS','\'; global $___LOCAL_SKILL203__VARS__ragecost; ${$___TEMP_VARNAME}[\'ragecost\']=&$___LOCAL_SKILL203__VARS__ragecost; global $___LOCAL_SKILL203__VARS__wep_skillkind_req; ${$___TEMP_VARNAME}[\'wep_skillkind_req\']=&$___LOCAL_SKILL203__VARS__wep_skillkind_req; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL203__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL203__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL203__VARS__ragecost,$___LOCAL_SKILL203__VARS__wep_skillkind_req;
$___PRIVATE_SKILL203__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL203__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL203__VARS__ragecost=&$ragecost;$___LOCAL_SKILL203__VARS__wep_skillkind_req=&$wep_skillkind_req;
unset($ragecost,$wep_skillkind_req);
hook_register('skill203','acquire203');hook_register('skill203','lost203');hook_register('skill203','check_unlocked203');hook_register('skill203','get_rage_cost203');hook_register('skill203','strike_prepare');hook_register('skill203','get_hitrate_multiplier');hook_register('skill203','get_physical_dmg_multiplier');hook_register('skill203','parse_news');
function ___post_init() { global $___PRIVATE_SKILL203__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL203__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL203__VARS__ragecost,$___LOCAL_SKILL203__VARS__wep_skillkind_req;
$___LOCAL_SKILL203__VARS__ragecost=$GLOBALS['ragecost'];$___LOCAL_SKILL203__VARS__wep_skillkind_req=$GLOBALS['wep_skillkind_req'];
unset($GLOBALS['ragecost'],$GLOBALS['wep_skillkind_req']);
}
	
}

?>