<?php

namespace miracletrap
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/items/miracletrap/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_MIRACLETRAP_PRESET_VARS','');
define('___LOAD_MOD_MIRACLETRAP_PRESET_VARS','');
define('MODULE_MIRACLETRAP_GLOBALS_VARNAMES','');
define('MOD_MIRACLETRAP',1);
define('IMPORT_MODULE_MIRACLETRAP_GLOBALS','');
define('PREFIX_MODULE_MIRACLETRAP_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_MIRACLETRAP_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_MIRACLETRAP__VARS_____PRIVATE_PFUNC,$___PRIVATE_MIRACLETRAP__VARS_____PRIVATE_CFUNC;
$___PRIVATE_MIRACLETRAP__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_MIRACLETRAP__VARS_____PRIVATE_CFUNC=Array();

hook_register('miracletrap','trapcheck');hook_register('miracletrap','trap');hook_register('miracletrap','get_trap_damage');hook_register('miracletrap','check_trapdef_proc');
function ___post_init() { global $___PRIVATE_MIRACLETRAP__VARS_____PRIVATE_PFUNC,$___PRIVATE_MIRACLETRAP__VARS_____PRIVATE_CFUNC;


}
	
}

?>