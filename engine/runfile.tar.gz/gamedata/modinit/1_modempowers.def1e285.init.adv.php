<?php

namespace empowers
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/items/empowers/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EMPOWERS_PRESET_VARS','');
define('___LOAD_MOD_EMPOWERS_PRESET_VARS','');
define('MODULE_EMPOWERS_GLOBALS_VARNAMES','');
define('MOD_EMPOWERS',1);
define('IMPORT_MODULE_EMPOWERS_GLOBALS','');
define('PREFIX_MODULE_EMPOWERS_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_EMPOWERS_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EMPOWERS__VARS_____PRIVATE_PFUNC,$___PRIVATE_EMPOWERS__VARS_____PRIVATE_CFUNC;
$___PRIVATE_EMPOWERS__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EMPOWERS__VARS_____PRIVATE_CFUNC=Array();

hook_register('empowers','parse_itmuse_desc');hook_register('empowers','check_nail');hook_register('empowers','use_nail');hook_register('empowers','check_hone');hook_register('empowers','use_hone');hook_register('empowers','use_weapon_improvement');hook_register('empowers','itemuse');hook_register('empowers','use_sewing_kit');hook_register('empowers','parse_news');
function ___post_init() { global $___PRIVATE_EMPOWERS__VARS_____PRIVATE_PFUNC,$___PRIVATE_EMPOWERS__VARS_____PRIVATE_CFUNC;


}
	
}

?>