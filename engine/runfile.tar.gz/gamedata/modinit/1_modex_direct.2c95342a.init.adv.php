<?php

namespace ex_direct
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/ex_direct/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EX_DIRECT_PRESET_VARS','');
define('___LOAD_MOD_EX_DIRECT_PRESET_VARS','');
define('MODULE_EX_DIRECT_GLOBALS_VARNAMES','');
define('MOD_EX_DIRECT',1);
define('IMPORT_MODULE_EX_DIRECT_GLOBALS','');
define('PREFIX_MODULE_EX_DIRECT_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_EX_DIRECT_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EX_DIRECT__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_DIRECT__VARS_____PRIVATE_CFUNC;
$___PRIVATE_EX_DIRECT__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EX_DIRECT__VARS_____PRIVATE_CFUNC=Array();

hook_register('ex_direct','get_ex_direct_proc_rate');hook_register('ex_direct','strike_prepare');hook_register('ex_direct','skill_enabled_core');
function ___post_init() { global $___PRIVATE_EX_DIRECT__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_DIRECT__VARS_____PRIVATE_CFUNC;


}
	
}

?>