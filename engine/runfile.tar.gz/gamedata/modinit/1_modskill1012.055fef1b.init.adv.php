<?php

namespace skill1012
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/gmskills/skill1012/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL1012_PRESET_VARS','');
define('___LOAD_MOD_SKILL1012_PRESET_VARS','');
define('MOD_SKILL1012_INFO','active;unique;');
define('MOD_SKILL1012_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\gmskills\\skill1012/desc');
define('MOD_SKILL1012_PROFILECMD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\gmskills\\skill1012/profilecmd');
define('MOD_SKILL1012_SUB_PAGE','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\gmskills\\skill1012/sub_page');
define('MODULE_SKILL1012_GLOBALS_VARNAMES','');
define('MOD_SKILL1012',1);
define('IMPORT_MODULE_SKILL1012_GLOBALS','');
define('PREFIX_MODULE_SKILL1012_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL1012_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL1012__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1012__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL1012__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL1012__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill1012','acquire1012');hook_register('skill1012','lost1012');hook_register('skill1012','check_unlocked1012');hook_register('skill1012','skill1012_sub_page');hook_register('skill1012','skill1012_show_var');hook_register('skill1012','act');
function ___post_init() { global $___PRIVATE_SKILL1012__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL1012__VARS_____PRIVATE_CFUNC;


}
	
}

?>