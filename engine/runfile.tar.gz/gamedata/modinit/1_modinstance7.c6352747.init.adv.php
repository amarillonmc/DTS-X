<?php

namespace instance7
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/instance/instance7_tutorial/'.$___TEMP_key; 
	
	$___PRESET_INSTANCE7__VARS__npcinfo_instance7=$npcinfo_instance7;
function ___pre_init() { global $___PRESET_INSTANCE7__VARS__npcinfo_instance7,$npcinfo_instance7;$npcinfo_instance7=$___PRESET_INSTANCE7__VARS__npcinfo_instance7; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_INSTANCE7_PRESET_VARS','$___PRESET_INSTANCE7__VARS__npcinfo_instance7=$npcinfo_instance7;');
define('___LOAD_MOD_INSTANCE7_PRESET_VARS','global $___PRESET_INSTANCE7__VARS__npcinfo_instance7,$npcinfo_instance7;$npcinfo_instance7=$___PRESET_INSTANCE7__VARS__npcinfo_instance7;');
define('MODULE_INSTANCE7_GLOBALS_VARNAMES','npcinfo_instance7');
define('MOD_INSTANCE7',1);
define('IMPORT_MODULE_INSTANCE7_GLOBALS','global $___LOCAL_INSTANCE7__VARS__npcinfo_instance7; $npcinfo_instance7=&$___LOCAL_INSTANCE7__VARS__npcinfo_instance7; ');
define('PREFIX_MODULE_INSTANCE7_GLOBALS','\'; global $___LOCAL_INSTANCE7__VARS__npcinfo_instance7; ${$___TEMP_PREFIX.\'npcinfo_instance7\'}=&$___LOCAL_INSTANCE7__VARS__npcinfo_instance7; unset($___TEMP_PREFIX); ');
define('MODULE_INSTANCE7_GLOBALS','\'; global $___LOCAL_INSTANCE7__VARS__npcinfo_instance7; ${$___TEMP_VARNAME}[\'npcinfo_instance7\']=&$___LOCAL_INSTANCE7__VARS__npcinfo_instance7; unset($___TEMP_VARNAME); ');

global $___PRIVATE_INSTANCE7__VARS_____PRIVATE_PFUNC,$___PRIVATE_INSTANCE7__VARS_____PRIVATE_CFUNC,$___LOCAL_INSTANCE7__VARS__npcinfo_instance7;
$___PRIVATE_INSTANCE7__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_INSTANCE7__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_INSTANCE7__VARS__npcinfo_instance7=&$npcinfo_instance7;
unset($npcinfo_instance7);
hook_register('instance7','get_enter_battlefield_card');hook_register('instance7','get_npclist');hook_register('instance7','get_shopconfig');hook_register('instance7','get_itemfilecont');hook_register('instance7','get_trapfilecont');hook_register('instance7','get_startingitemfilecont');
function ___post_init() { global $___PRIVATE_INSTANCE7__VARS_____PRIVATE_PFUNC,$___PRIVATE_INSTANCE7__VARS_____PRIVATE_CFUNC,$___LOCAL_INSTANCE7__VARS__npcinfo_instance7;
$___LOCAL_INSTANCE7__VARS__npcinfo_instance7=$GLOBALS['npcinfo_instance7'];
unset($GLOBALS['npcinfo_instance7']);
}
	
}

?>