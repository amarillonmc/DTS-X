<?php

namespace gameflow_duel
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'core/gameflow/gameflow_duel/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_GAMEFLOW_DUEL_PRESET_VARS','');
define('___LOAD_MOD_GAMEFLOW_DUEL_PRESET_VARS','');
define('MODULE_GAMEFLOW_DUEL_GLOBALS_VARNAMES','');
define('MOD_GAMEFLOW_DUEL',1);
define('IMPORT_MODULE_GAMEFLOW_DUEL_GLOBALS','');
define('PREFIX_MODULE_GAMEFLOW_DUEL_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_GAMEFLOW_DUEL_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_GAMEFLOW_DUEL__VARS_____PRIVATE_PFUNC,$___PRIVATE_GAMEFLOW_DUEL__VARS_____PRIVATE_CFUNC;
$___PRIVATE_GAMEFLOW_DUEL__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_GAMEFLOW_DUEL__VARS_____PRIVATE_CFUNC=Array();

hook_register('gameflow_duel','duel');hook_register('gameflow_duel','is_gamestate_duel');hook_register('gameflow_duel','parse_news');hook_register('gameflow_duel','discover_player_filter_alive');hook_register('gameflow_duel','calculate_meetman_rate');
function ___post_init() { global $___PRIVATE_GAMEFLOW_DUEL__VARS_____PRIVATE_PFUNC,$___PRIVATE_GAMEFLOW_DUEL__VARS_____PRIVATE_CFUNC;


}
	
}

?>