<?php

namespace itemmix_overlay
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/itemmix/itemmix_overlay/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ITEMMIX_OVERLAY_PRESET_VARS','');
define('___LOAD_MOD_ITEMMIX_OVERLAY_PRESET_VARS','');
define('MODULE_ITEMMIX_OVERLAY_GLOBALS_VARNAMES','');
define('MOD_ITEMMIX_OVERLAY',1);
define('IMPORT_MODULE_ITEMMIX_OVERLAY_GLOBALS','');
define('PREFIX_MODULE_ITEMMIX_OVERLAY_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_ITEMMIX_OVERLAY_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ITEMMIX_OVERLAY__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEMMIX_OVERLAY__VARS_____PRIVATE_CFUNC;
$___PRIVATE_ITEMMIX_OVERLAY__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ITEMMIX_OVERLAY__VARS_____PRIVATE_CFUNC=Array();

hook_register('itemmix_overlay','get_itemmix_overlay_filename');hook_register('itemmix_overlay','itemmix_prepare_overlay');hook_register('itemmix_overlay','itemmix_star_culc_overlay');hook_register('itemmix_overlay','check_valid_overlay_material');hook_register('itemmix_overlay','itemmix_overlay_check');hook_register('itemmix_overlay','itemmix_get_result');
function ___post_init() { global $___PRIVATE_ITEMMIX_OVERLAY__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEMMIX_OVERLAY__VARS_____PRIVATE_CFUNC;


}
	
}

?>