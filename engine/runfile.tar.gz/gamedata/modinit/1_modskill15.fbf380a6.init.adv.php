<?php

namespace skill15
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill15/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL15_PRESET_VARS','');
define('___LOAD_MOD_SKILL15_PRESET_VARS','');
define('MOD_SKILL15_INFO','club;feature;');
define('MOD_SKILL15_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill15/desc');
define('MODULE_SKILL15_GLOBALS_VARNAMES','');
define('MOD_SKILL15',1);
define('IMPORT_MODULE_SKILL15_GLOBALS','');
define('PREFIX_MODULE_SKILL15_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL15_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL15__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL15__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL15__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL15__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill15','acquire15');hook_register('skill15','lost15');hook_register('skill15','check_unlocked15');hook_register('skill15','lvlup');
function ___post_init() { global $___PRIVATE_SKILL15__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL15__VARS_____PRIVATE_CFUNC;


}
	
}

?>