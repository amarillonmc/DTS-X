<?php

namespace skill109
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill109/'.$___TEMP_key; 
	
	$___PRESET_SKILL109__VARS__skill109_tempskill_time=$skill109_tempskill_time;
function ___pre_init() { global $___PRESET_SKILL109__VARS__skill109_tempskill_time,$skill109_tempskill_time;$skill109_tempskill_time=$___PRESET_SKILL109__VARS__skill109_tempskill_time; }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL109_PRESET_VARS','$___PRESET_SKILL109__VARS__skill109_tempskill_time=$skill109_tempskill_time;');
define('___LOAD_MOD_SKILL109_PRESET_VARS','global $___PRESET_SKILL109__VARS__skill109_tempskill_time,$skill109_tempskill_time;$skill109_tempskill_time=$___PRESET_SKILL109__VARS__skill109_tempskill_time;');
define('MOD_SKILL109_INFO','club;upgrade;locked;');
define('MOD_SKILL109_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill109/desc');
define('MODULE_SKILL109_GLOBALS_VARNAMES','skill109_tempskill_time');
define('MOD_SKILL109',1);
define('IMPORT_MODULE_SKILL109_GLOBALS','global $___LOCAL_SKILL109__VARS__skill109_tempskill_time; $skill109_tempskill_time=&$___LOCAL_SKILL109__VARS__skill109_tempskill_time; ');
define('PREFIX_MODULE_SKILL109_GLOBALS','\'; global $___LOCAL_SKILL109__VARS__skill109_tempskill_time; ${$___TEMP_PREFIX.\'skill109_tempskill_time\'}=&$___LOCAL_SKILL109__VARS__skill109_tempskill_time; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL109_GLOBALS','\'; global $___LOCAL_SKILL109__VARS__skill109_tempskill_time; ${$___TEMP_VARNAME}[\'skill109_tempskill_time\']=&$___LOCAL_SKILL109__VARS__skill109_tempskill_time; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL109__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL109__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL109__VARS__skill109_tempskill_time;
$___PRIVATE_SKILL109__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL109__VARS_____PRIVATE_CFUNC=Array();$___LOCAL_SKILL109__VARS__skill109_tempskill_time=&$skill109_tempskill_time;
unset($skill109_tempskill_time);
hook_register('skill109','acquire109');hook_register('skill109','lost109');hook_register('skill109','check_unlocked109');hook_register('skill109','upgrade109');
function ___post_init() { global $___PRIVATE_SKILL109__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL109__VARS_____PRIVATE_CFUNC,$___LOCAL_SKILL109__VARS__skill109_tempskill_time;
$___LOCAL_SKILL109__VARS__skill109_tempskill_time=$GLOBALS['skill109_tempskill_time'];
unset($GLOBALS['skill109_tempskill_time']);
}
	
}

?>