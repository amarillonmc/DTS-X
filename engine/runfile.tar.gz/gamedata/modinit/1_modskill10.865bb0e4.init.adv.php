<?php

namespace skill10
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill10/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL10_PRESET_VARS','');
define('___LOAD_MOD_SKILL10_PRESET_VARS','');
define('MOD_SKILL10_INFO','club;upgrade;locked;');
define('MOD_SKILL10_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill10/desc');
define('MODULE_SKILL10_GLOBALS_VARNAMES','');
define('MOD_SKILL10',1);
define('IMPORT_MODULE_SKILL10_GLOBALS','');
define('PREFIX_MODULE_SKILL10_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL10_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL10__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL10__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL10__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL10__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill10','acquire10');hook_register('skill10','lost10');hook_register('skill10','check_unlocked10');hook_register('skill10','upgrade10');
function ___post_init() { global $___PRIVATE_SKILL10__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL10__VARS_____PRIVATE_CFUNC;


}
	
}

?>