<?php

namespace skill17
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill17/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL17_PRESET_VARS','');
define('___LOAD_MOD_SKILL17_PRESET_VARS','');
define('MOD_SKILL17_INFO','club;feature;');
define('MOD_SKILL17_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill17/desc');
define('MODULE_SKILL17_GLOBALS_VARNAMES','');
define('MOD_SKILL17',1);
define('IMPORT_MODULE_SKILL17_GLOBALS','');
define('PREFIX_MODULE_SKILL17_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL17_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL17__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL17__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL17__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL17__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill17','acquire17');hook_register('skill17','lost17');hook_register('skill17','check_unlocked17');hook_register('skill17','lvlup');
function ___post_init() { global $___PRIVATE_SKILL17__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL17__VARS_____PRIVATE_CFUNC;


}
	
}

?>