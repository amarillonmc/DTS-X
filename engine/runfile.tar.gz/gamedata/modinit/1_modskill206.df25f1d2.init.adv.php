<?php

namespace skill206
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill206/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL206_PRESET_VARS','');
define('___LOAD_MOD_SKILL206_PRESET_VARS','');
define('MOD_SKILL206_INFO','club;locked;');
define('MOD_SKILL206_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill206/desc');
define('MODULE_SKILL206_GLOBALS_VARNAMES','');
define('MOD_SKILL206',1);
define('IMPORT_MODULE_SKILL206_GLOBALS','');
define('PREFIX_MODULE_SKILL206_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL206_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL206__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL206__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL206__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL206__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill206','acquire206');hook_register('skill206','lost206');hook_register('skill206','get_gunner_skillpoint_need');hook_register('skill206','check_unlocked206');hook_register('skill206','apply_total_damage_modifier_seckill');
function ___post_init() { global $___PRIVATE_SKILL206__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL206__VARS_____PRIVATE_CFUNC;


}
	
}

?>