<?php

namespace skill20
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill20/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL20_PRESET_VARS','');
define('___LOAD_MOD_SKILL20_PRESET_VARS','');
define('MOD_SKILL20_INFO','club;hidden;');
define('MODULE_SKILL20_GLOBALS_VARNAMES','');
define('MOD_SKILL20',1);
define('IMPORT_MODULE_SKILL20_GLOBALS','');
define('PREFIX_MODULE_SKILL20_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL20_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL20__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL20__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL20__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL20__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill20','acquire20');hook_register('skill20','lost20');hook_register('skill20','itemmix_success');
function ___post_init() { global $___PRIVATE_SKILL20__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL20__VARS_____PRIVATE_CFUNC;


}
	
}

?>