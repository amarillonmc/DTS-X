<?php

namespace item_uv
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/items/item_uv/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ITEM_UV_PRESET_VARS','');
define('___LOAD_MOD_ITEM_UV_PRESET_VARS','');
define('MODULE_ITEM_UV_GLOBALS_VARNAMES','');
define('MOD_ITEM_UV',1);
define('IMPORT_MODULE_ITEM_UV_GLOBALS','');
define('PREFIX_MODULE_ITEM_UV_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_ITEM_UV_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ITEM_UV__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_UV__VARS_____PRIVATE_CFUNC;
$___PRIVATE_ITEM_UV__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ITEM_UV__VARS_____PRIVATE_CFUNC=Array();

hook_register('item_uv','parse_itmuse_desc');hook_register('item_uv','calc_skillbook_efct');hook_register('item_uv','itemuse');hook_register('item_uv','item_uv_getcard');hook_register('item_uv','parse_news');
function ___post_init() { global $___PRIVATE_ITEM_UV__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_UV__VARS_____PRIVATE_CFUNC;


}
	
}

?>