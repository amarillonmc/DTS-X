<?php

namespace skill22
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill22/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL22_PRESET_VARS','');
define('___LOAD_MOD_SKILL22_PRESET_VARS','');
define('MOD_SKILL22_INFO','club;hidden;');
define('MODULE_SKILL22_GLOBALS_VARNAMES','');
define('MOD_SKILL22',1);
define('IMPORT_MODULE_SKILL22_GLOBALS','');
define('PREFIX_MODULE_SKILL22_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL22_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL22__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL22__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL22__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL22__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill22','acquire22');hook_register('skill22','lost22');hook_register('skill22','get_trap_escape_rate');hook_register('skill22','calculate_trap_reuse_rate');hook_register('skill22','calculate_real_trap_obbs');
function ___post_init() { global $___PRIVATE_SKILL22__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL22__VARS_____PRIVATE_CFUNC;


}
	
}

?>