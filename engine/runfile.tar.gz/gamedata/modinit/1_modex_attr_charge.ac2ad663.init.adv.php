<?php

namespace ex_attr_charge
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/ex_attr_charge/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EX_ATTR_CHARGE_PRESET_VARS','');
define('___LOAD_MOD_EX_ATTR_CHARGE_PRESET_VARS','');
define('MODULE_EX_ATTR_CHARGE_GLOBALS_VARNAMES','');
define('MOD_EX_ATTR_CHARGE',1);
define('IMPORT_MODULE_EX_ATTR_CHARGE_GLOBALS','');
define('PREFIX_MODULE_EX_ATTR_CHARGE_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_EX_ATTR_CHARGE_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EX_ATTR_CHARGE__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_ATTR_CHARGE__VARS_____PRIVATE_CFUNC;
$___PRIVATE_EX_ATTR_CHARGE__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EX_ATTR_CHARGE__VARS_____PRIVATE_CFUNC=Array();

hook_register('ex_attr_charge','get_ex_charge_proc_rate');hook_register('ex_attr_charge','check_charge_proc');hook_register('ex_attr_charge','get_external_def_multiplier');hook_register('ex_attr_charge','strike_prepare');
function ___post_init() { global $___PRIVATE_EX_ATTR_CHARGE__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_ATTR_CHARGE__VARS_____PRIVATE_CFUNC;


}
	
}

?>