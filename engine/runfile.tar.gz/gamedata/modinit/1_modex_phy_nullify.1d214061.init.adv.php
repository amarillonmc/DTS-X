<?php

namespace ex_phy_nullify
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/ex_phy_nullify/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EX_PHY_NULLIFY_PRESET_VARS','');
define('___LOAD_MOD_EX_PHY_NULLIFY_PRESET_VARS','');
define('MODULE_EX_PHY_NULLIFY_GLOBALS_VARNAMES','');
define('MOD_EX_PHY_NULLIFY',1);
define('IMPORT_MODULE_EX_PHY_NULLIFY_GLOBALS','');
define('PREFIX_MODULE_EX_PHY_NULLIFY_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_EX_PHY_NULLIFY_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EX_PHY_NULLIFY__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_PHY_NULLIFY__VARS_____PRIVATE_CFUNC;
$___PRIVATE_EX_PHY_NULLIFY__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EX_PHY_NULLIFY__VARS_____PRIVATE_CFUNC=Array();

hook_register('ex_phy_nullify','get_ex_phy_nullify_proc_rate');hook_register('ex_phy_nullify','check_physical_nullify');hook_register('ex_phy_nullify','get_physical_dmg_multiplier');hook_register('ex_phy_nullify','check_physical_def_attr');hook_register('ex_phy_nullify','put_charge_success_words');hook_register('ex_phy_nullify','get_physical_dmg');hook_register('ex_phy_nullify','strike_prepare');hook_register('ex_phy_nullify','use_sewing_kit');hook_register('ex_phy_nullify','autosewingkit_single');hook_register('ex_phy_nullify','geming_objvalid');
function ___post_init() { global $___PRIVATE_EX_PHY_NULLIFY__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_PHY_NULLIFY__VARS_____PRIVATE_CFUNC;


}
	
}

?>