<?php

namespace skill108
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill108/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL108_PRESET_VARS','');
define('___LOAD_MOD_SKILL108_PRESET_VARS','');
define('MOD_SKILL108_INFO','club;feature;');
define('MOD_SKILL108_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill108/desc');
define('MODULE_SKILL108_GLOBALS_VARNAMES','');
define('MOD_SKILL108',1);
define('IMPORT_MODULE_SKILL108_GLOBALS','');
define('PREFIX_MODULE_SKILL108_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL108_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL108__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL108__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL108__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL108__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill108','acquire108');hook_register('skill108','lost108');hook_register('skill108','check_unlocked108');hook_register('skill108','lvlup');hook_register('skill108','getexp');hook_register('skill108','calculate_active_obbs_multiplier');hook_register('skill108','get_final_dmg_multiplier');
function ___post_init() { global $___PRIVATE_SKILL108__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL108__VARS_____PRIVATE_CFUNC;


}
	
}

?>