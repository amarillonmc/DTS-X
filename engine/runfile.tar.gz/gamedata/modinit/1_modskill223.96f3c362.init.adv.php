<?php

namespace skill223
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill223/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL223_PRESET_VARS','');
define('___LOAD_MOD_SKILL223_PRESET_VARS','');
define('MOD_SKILL223_INFO','club;battle;limited;');
define('MOD_SKILL223_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill223/desc');
define('MOD_SKILL223_BATTLECMD_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill223/battlecmd_desc');
define('MODULE_SKILL223_GLOBALS_VARNAMES','');
define('MOD_SKILL223',1);
define('IMPORT_MODULE_SKILL223_GLOBALS','');
define('PREFIX_MODULE_SKILL223_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL223_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL223__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL223__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL223__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL223__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill223','acquire223');hook_register('skill223','lost223');hook_register('skill223','check_unlocked223');hook_register('skill223','get_remaintime223');hook_register('skill223','strike_prepare');hook_register('skill223','get_hitrate_change');hook_register('skill223','get_final_dmg_multiplier');hook_register('skill223','parse_news');
function ___post_init() { global $___PRIVATE_SKILL223__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL223__VARS_____PRIVATE_CFUNC;


}
	
}

?>