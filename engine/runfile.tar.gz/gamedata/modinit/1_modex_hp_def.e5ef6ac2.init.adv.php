<?php

namespace ex_hp_def
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/ex_hp_def/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EX_HP_DEF_PRESET_VARS','');
define('___LOAD_MOD_EX_HP_DEF_PRESET_VARS','');
define('MODULE_EX_HP_DEF_GLOBALS_VARNAMES','');
define('MOD_EX_HP_DEF',1);
define('IMPORT_MODULE_EX_HP_DEF_GLOBALS','');
define('PREFIX_MODULE_EX_HP_DEF_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_EX_HP_DEF_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EX_HP_DEF__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_HP_DEF__VARS_____PRIVATE_CFUNC;
$___PRIVATE_EX_HP_DEF__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EX_HP_DEF__VARS_____PRIVATE_CFUNC=Array();

hook_register('ex_hp_def','calculate_hp_rev_dmg');hook_register('ex_hp_def','get_dmg_def_proc_rate');hook_register('ex_hp_def','check_dmg_def_attr');hook_register('ex_hp_def','apply_total_damage_modifier_limit');hook_register('ex_hp_def','player_damaged_enemy');
function ___post_init() { global $___PRIVATE_EX_HP_DEF__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_HP_DEF__VARS_____PRIVATE_CFUNC;


}
	
}

?>