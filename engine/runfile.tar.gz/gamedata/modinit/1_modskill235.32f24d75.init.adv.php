<?php

namespace skill235
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill235/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL235_PRESET_VARS','');
define('___LOAD_MOD_SKILL235_PRESET_VARS','');
define('MOD_SKILL235_INFO','club;active;');
define('MOD_SKILL235_PROFILECMD','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill235/profilecmd');
define('MOD_SKILL235_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill235/desc');
define('MODULE_SKILL235_GLOBALS_VARNAMES','');
define('MOD_SKILL235',1);
define('IMPORT_MODULE_SKILL235_GLOBALS','');
define('PREFIX_MODULE_SKILL235_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL235_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL235__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL235__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL235__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL235__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill235','acquire235');hook_register('skill235','lost235');hook_register('skill235','check_unlocked235');hook_register('skill235','wscan');hook_register('skill235','act');
function ___post_init() { global $___PRIVATE_SKILL235__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL235__VARS_____PRIVATE_CFUNC;


}
	
}

?>