<?php

namespace skill221
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill221/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL221_PRESET_VARS','');
define('___LOAD_MOD_SKILL221_PRESET_VARS','');
define('MOD_SKILL221_INFO','club;');
define('MOD_SKILL221_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill221/desc');
define('MODULE_SKILL221_GLOBALS_VARNAMES','');
define('MOD_SKILL221',1);
define('IMPORT_MODULE_SKILL221_GLOBALS','');
define('PREFIX_MODULE_SKILL221_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL221_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL221__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL221__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL221__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL221__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill221','acquire221');hook_register('skill221','lost221');hook_register('skill221','check_unlocked221');hook_register('skill221','get_skill221_lasttime');hook_register('skill221','strike_finish');
function ___post_init() { global $___PRIVATE_SKILL221__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL221__VARS_____PRIVATE_CFUNC;


}
	
}

?>