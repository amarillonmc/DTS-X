<?php

namespace gameflow_base
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'core/gameflow/gameflow_base/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_GAMEFLOW_BASE_PRESET_VARS','');
define('___LOAD_MOD_GAMEFLOW_BASE_PRESET_VARS','');
define('MODULE_GAMEFLOW_BASE_GLOBALS_VARNAMES','');
define('MOD_GAMEFLOW_BASE',1);
define('IMPORT_MODULE_GAMEFLOW_BASE_GLOBALS','');
define('PREFIX_MODULE_GAMEFLOW_BASE_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_GAMEFLOW_BASE_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_GAMEFLOW_BASE__VARS_____PRIVATE_PFUNC,$___PRIVATE_GAMEFLOW_BASE__VARS_____PRIVATE_CFUNC;
$___PRIVATE_GAMEFLOW_BASE__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_GAMEFLOW_BASE__VARS_____PRIVATE_CFUNC=Array();

hook_register('gameflow_base','gamestate_prepare_game');hook_register('gameflow_base','gamestate_start_game');hook_register('gameflow_base','gamestateupdate');hook_register('gameflow_base','is_gamestate_combo');hook_register('gameflow_base','checkendgame');hook_register('gameflow_base','update_valid_alivenum');hook_register('gameflow_base','check_valid_alivenum_single');hook_register('gameflow_base','updategame');
function ___post_init() { global $___PRIVATE_GAMEFLOW_BASE__VARS_____PRIVATE_PFUNC,$___PRIVATE_GAMEFLOW_BASE__VARS_____PRIVATE_CFUNC;


}
	
}

?>