<?php

namespace item_um
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'base/items/item_um/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ITEM_UM_PRESET_VARS','');
define('___LOAD_MOD_ITEM_UM_PRESET_VARS','');
define('MODULE_ITEM_UM_GLOBALS_VARNAMES','');
define('MOD_ITEM_UM',1);
define('IMPORT_MODULE_ITEM_UM_GLOBALS','');
define('PREFIX_MODULE_ITEM_UM_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_ITEM_UM_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ITEM_UM__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_UM__VARS_____PRIVATE_CFUNC;
$___PRIVATE_ITEM_UM__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ITEM_UM__VARS_____PRIVATE_CFUNC=Array();

hook_register('item_um','calc_skillmed_value');hook_register('item_um','calc_skillmed_efct');hook_register('item_um','itemuse_um');hook_register('item_um','itemuse');
function ___post_init() { global $___PRIVATE_ITEM_UM__VARS_____PRIVATE_PFUNC,$___PRIVATE_ITEM_UM__VARS_____PRIVATE_CFUNC;


}
	
}

?>