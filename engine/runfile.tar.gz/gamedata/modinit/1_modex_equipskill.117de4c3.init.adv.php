<?php

namespace ex_equipskill
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/ex_equipskill/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EX_EQUIPSKILL_PRESET_VARS','');
define('___LOAD_MOD_EX_EQUIPSKILL_PRESET_VARS','');
define('MODULE_EX_EQUIPSKILL_GLOBALS_VARNAMES','');
define('MOD_EX_EQUIPSKILL',1);
define('IMPORT_MODULE_EX_EQUIPSKILL_GLOBALS','');
define('PREFIX_MODULE_EX_EQUIPSKILL_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_EX_EQUIPSKILL_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EX_EQUIPSKILL__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_EQUIPSKILL__VARS_____PRIVATE_CFUNC;
$___PRIVATE_EX_EQUIPSKILL__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EX_EQUIPSKILL__VARS_____PRIVATE_CFUNC=Array();

hook_register('ex_equipskill','itemuse');hook_register('ex_equipskill','check_skill_available');hook_register('ex_equipskill','get_itmsk_desc_single_comp_process');
function ___post_init() { global $___PRIVATE_EX_EQUIPSKILL__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_EQUIPSKILL__VARS_____PRIVATE_CFUNC;


}
	
}

?>