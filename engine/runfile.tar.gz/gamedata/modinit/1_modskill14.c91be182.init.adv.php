<?php

namespace skill14
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill14/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL14_PRESET_VARS','');
define('___LOAD_MOD_SKILL14_PRESET_VARS','');
define('MOD_SKILL14_INFO','club;feature;');
define('MOD_SKILL14_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill14/desc');
define('MODULE_SKILL14_GLOBALS_VARNAMES','');
define('MOD_SKILL14',1);
define('IMPORT_MODULE_SKILL14_GLOBALS','');
define('PREFIX_MODULE_SKILL14_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL14_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL14__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL14__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL14__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL14__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill14','acquire14');hook_register('skill14','lost14');hook_register('skill14','check_unlocked14');hook_register('skill14','lvlup');
function ___post_init() { global $___PRIVATE_SKILL14__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL14__VARS_____PRIVATE_CFUNC;


}
	
}

?>