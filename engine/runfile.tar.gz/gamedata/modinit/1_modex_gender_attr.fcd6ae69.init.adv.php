<?php

namespace ex_gender_attr
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/attr/ex_gender_attr/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_EX_GENDER_ATTR_PRESET_VARS','');
define('___LOAD_MOD_EX_GENDER_ATTR_PRESET_VARS','');
define('MODULE_EX_GENDER_ATTR_GLOBALS_VARNAMES','');
define('MOD_EX_GENDER_ATTR',1);
define('IMPORT_MODULE_EX_GENDER_ATTR_GLOBALS','');
define('PREFIX_MODULE_EX_GENDER_ATTR_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_EX_GENDER_ATTR_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_EX_GENDER_ATTR__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_GENDER_ATTR__VARS_____PRIVATE_CFUNC;
$___PRIVATE_EX_GENDER_ATTR__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_EX_GENDER_ATTR__VARS_____PRIVATE_CFUNC=Array();

hook_register('ex_gender_attr','get_gender_bewitch_proc_rate');hook_register('ex_gender_attr','get_gender_enrage_proc_rate');hook_register('ex_gender_attr','check_gender_proc');hook_register('ex_gender_attr','get_physical_dmg_multiplier');
function ___post_init() { global $___PRIVATE_EX_GENDER_ATTR__VARS_____PRIVATE_PFUNC,$___PRIVATE_EX_GENDER_ATTR__VARS_____PRIVATE_CFUNC;


}
	
}

?>