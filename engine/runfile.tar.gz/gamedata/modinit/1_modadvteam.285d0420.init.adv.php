<?php

namespace advteam
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/misc/advteam/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_ADVTEAM_PRESET_VARS','');
define('___LOAD_MOD_ADVTEAM_PRESET_VARS','');
define('MOD_ADVTEAM_TEAM','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\misc\\advteam/team');
define('MODULE_ADVTEAM_GLOBALS_VARNAMES','');
define('MOD_ADVTEAM',1);
define('IMPORT_MODULE_ADVTEAM_GLOBALS','');
define('PREFIX_MODULE_ADVTEAM_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_ADVTEAM_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_ADVTEAM__VARS_____PRIVATE_PFUNC,$___PRIVATE_ADVTEAM__VARS_____PRIVATE_CFUNC;
$___PRIVATE_ADVTEAM__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_ADVTEAM__VARS_____PRIVATE_CFUNC=Array();

hook_register('advteam','get_advteam_html');hook_register('advteam','act');
function ___post_init() { global $___PRIVATE_ADVTEAM__VARS_____PRIVATE_PFUNC,$___PRIVATE_ADVTEAM__VARS_____PRIVATE_CFUNC;


}
	
}

?>