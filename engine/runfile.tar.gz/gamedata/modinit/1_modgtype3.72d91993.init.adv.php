<?php

namespace gtype3
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/instance/gtype3/main/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_GTYPE3_PRESET_VARS','');
define('___LOAD_MOD_GTYPE3_PRESET_VARS','');
define('MODULE_GTYPE3_GLOBALS_VARNAMES','');
define('MOD_GTYPE3',1);
define('IMPORT_MODULE_GTYPE3_GLOBALS','');
define('PREFIX_MODULE_GTYPE3_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_GTYPE3_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_GTYPE3__VARS_____PRIVATE_PFUNC,$___PRIVATE_GTYPE3__VARS_____PRIVATE_CFUNC;
$___PRIVATE_GTYPE3__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_GTYPE3__VARS_____PRIVATE_CFUNC=Array();

hook_register('gtype3','prepare_new_game');hook_register('gtype3','check_addarea_gameover');
function ___post_init() { global $___PRIVATE_GTYPE3__VARS_____PRIVATE_PFUNC,$___PRIVATE_GTYPE3__VARS_____PRIVATE_CFUNC;


}
	
}

?>