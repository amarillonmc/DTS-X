<?php

namespace skill18
{
	if (!defined('IN_GAME')) exit('Access Denied');
	foreach(explode(' ',$___MODULE_codelist) as $___TEMP_key) if ($___TEMP_key!="") include GAME_ROOT.__MOD_DIR__.'extra/club/skills/skill18/'.$___TEMP_key; 
	
	
function ___pre_init() {  }

	
	if (!$___TEMP_DRY_RUN) init();
	
	define('___SAVE_MOD_SKILL18_PRESET_VARS','');
define('___LOAD_MOD_SKILL18_PRESET_VARS','');
define('MOD_SKILL18_INFO','club;feature;');
define('MOD_SKILL18_DESC','D:\\phpstudy_pro\\WWW\\dts\\./include/modules/extra\\club\\skills\\skill18/desc');
define('MODULE_SKILL18_GLOBALS_VARNAMES','');
define('MOD_SKILL18',1);
define('IMPORT_MODULE_SKILL18_GLOBALS','');
define('PREFIX_MODULE_SKILL18_GLOBALS','\'; unset($___TEMP_PREFIX); ');
define('MODULE_SKILL18_GLOBALS','\'; unset($___TEMP_VARNAME); ');

global $___PRIVATE_SKILL18__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL18__VARS_____PRIVATE_CFUNC;
$___PRIVATE_SKILL18__VARS_____PRIVATE_PFUNC=Array();$___PRIVATE_SKILL18__VARS_____PRIVATE_CFUNC=Array();

hook_register('skill18','acquire18');hook_register('skill18','lost18');hook_register('skill18','check_unlocked18');hook_register('skill18','lvlup');
function ___post_init() { global $___PRIVATE_SKILL18__VARS_____PRIVATE_PFUNC,$___PRIVATE_SKILL18__VARS_____PRIVATE_CFUNC;


}
	
}

?>